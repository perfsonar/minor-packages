__version__ = '0.2.8'

VERSION = __version__
