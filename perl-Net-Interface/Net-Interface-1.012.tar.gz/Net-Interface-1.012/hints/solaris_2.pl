
$self->{DEFINE} .= '-DBSD_COMP';
