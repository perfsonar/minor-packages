.. _api-template-tags:

Template tags
=============

.. automodule:: guardian.templatetags.guardian_tags


get_obj_perms
-------------

.. autofunction:: guardian.templatetags.guardian_tags.get_obj_perms

