"""
Blank URLConf just to keep the test suite happy
"""
urlpatterns = []
