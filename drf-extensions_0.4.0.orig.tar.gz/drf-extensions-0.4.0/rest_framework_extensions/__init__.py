__version__ = '0.4.0'  # from 0.3.1

VERSION = __version__
