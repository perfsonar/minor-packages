Channel
=======
.. automodule:: pika.channel

Channel
-------
.. autoclass:: Channel
   :members:
   :inherited-members:
   :member-order: bysource
