from django.apps import AppConfig


class TestsApp(AppConfig):
    name = 'tests_app'
