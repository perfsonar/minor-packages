
default_app_config = 'tests.testapp.apps.TestappConfig'
