export ESMOND_ROOT=/opt/esmond
export ESMOND_CONF=$ESMOND_ROOT/esmond.conf
export DJANGO_SETTINGS_MODULE=esmond.settings
