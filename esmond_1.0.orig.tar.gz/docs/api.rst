Developer Reference
===================

:mod:`api` Module
-----------------

.. automodule:: api.api
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`models` Module
--------------------

.. automodule:: api.models
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`views` Module
-------------------

.. automodule:: api.views
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    api.client
