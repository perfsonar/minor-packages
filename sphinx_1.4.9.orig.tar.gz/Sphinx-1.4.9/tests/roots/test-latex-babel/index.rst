test-tocdepth
=============

.. toctree::
   :caption: Table of content

   foo
   bar
