test-directive-code
===================

.. toctree::
   :glob:

   *


Code blocks
-----------

.. code-block:: ruby
   :linenos:

       def ruby?
           false
       end


Literal Includes
----------------

.. literalinclude:: literal.inc
   :language: python
