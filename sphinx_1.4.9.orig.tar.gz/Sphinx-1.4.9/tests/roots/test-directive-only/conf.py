
project = 'test-directive-only'
exclude_patterns = ['_build']
