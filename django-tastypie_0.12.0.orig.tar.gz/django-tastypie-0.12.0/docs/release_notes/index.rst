Release Notes
=============

.. toctree::
   :maxdepth: 1

   v0.12.0
   v0.11.1
   v0.11.0
   v0.10.0
   v0.9.16
   v0.9.15
   v0.9.14
   v0.9.13
