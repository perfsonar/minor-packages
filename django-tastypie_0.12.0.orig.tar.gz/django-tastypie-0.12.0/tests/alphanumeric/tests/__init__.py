from alphanumeric.tests.views import *
from alphanumeric.tests.http import *
