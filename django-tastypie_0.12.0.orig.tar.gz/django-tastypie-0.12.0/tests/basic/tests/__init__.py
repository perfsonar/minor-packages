from basic.tests.http import *
from basic.tests.resources import *
from basic.tests.views import *