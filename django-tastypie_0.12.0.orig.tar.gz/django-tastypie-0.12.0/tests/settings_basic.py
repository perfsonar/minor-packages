from settings import *
INSTALLED_APPS.append('django.contrib.sessions')
INSTALLED_APPS.append('basic')

ROOT_URLCONF = 'basic.urls'

