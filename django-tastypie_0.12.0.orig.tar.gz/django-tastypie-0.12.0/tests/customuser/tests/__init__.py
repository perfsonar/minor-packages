from customuser.tests.custom_user import *
