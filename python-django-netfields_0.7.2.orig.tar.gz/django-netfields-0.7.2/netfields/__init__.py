from netfields.managers import NetManager
from netfields.fields import (InetAddressField, CidrAddressField,
                              MACAddressField)

default_app_config = 'netfields.apps.NetfieldsConfig'
