Aynscore Connection Adapter
===========================
.. automodule:: pika.adapters.asyncore_connection
.. autoclass:: pika.adapters.asyncore_connection.AsyncoreConnection
  :members:
  :inherited-members:
